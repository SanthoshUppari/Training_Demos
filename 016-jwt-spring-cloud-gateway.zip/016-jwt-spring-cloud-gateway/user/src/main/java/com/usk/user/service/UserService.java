package com.usk.user.service;

import com.usk.user.entity.User;

public interface UserService {

	User save(User user);
	
	User getUser(User user);

}
